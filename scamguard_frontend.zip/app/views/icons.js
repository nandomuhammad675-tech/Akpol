// VIEW: kumpulan ikon SVG
const IC = {
  shield:
    '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z"/><path d="m9 12 2 2 4-4"/>',
  link: '<path d="M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1 1"/><path d="M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1-1"/>',
  zap: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V8a4 4 0 0 1 8 0v3"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4-4"/>',
  doc: '<path d="M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8z"/><path d="M14 3v5h5M9 13h6M9 17h6"/>',
  alert: '<path d="M12 3 2 20h20z"/><path d="M12 10v4M12 17v.5"/>',
  x: '<circle cx="12" cy="12" r="9"/><path d="m9 9 6 6M15 9l-6 6"/>',
  ok: '<circle cx="12" cy="12" r="9"/><path d="m8 12 3 3 5-6"/>',
};

// Ikon solid untuk kartu fitur di Beranda
IC.bolt = '<path d="M13 2 4 14h7l-1 8 9-12h-7z" fill="currentColor"/>';
IC.shieldF =
  '<path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6z" fill="currentColor"/><path d="m8.5 12 2.5 2.5 4.5-5" fill="none" stroke="#fff" stroke-width="2.2"/>';
IC.db =
  '<ellipse cx="12" cy="5.5" rx="8" ry="3" fill="currentColor" stroke="none"/><path d="M4 8.2c0 1.7 3.6 3 8 3s8-1.3 8-3v3.3c0 1.7-3.6 3-8 3s-8-1.3-8-3z" fill="currentColor" stroke="none"/><path d="M4 14.3c0 1.7 3.6 3 8 3s8-1.3 8-3v3.2c0 1.7-3.6 3-8 3s-8-1.3-8-3z" fill="currentColor" stroke="none"/>';
IC.lockF =
  '<rect x="5" y="11" width="14" height="10" rx="2.5" fill="currentColor" stroke="none"/><path d="M8 11V8a4 4 0 0 1 8 0v3" fill="none" stroke="currentColor" stroke-width="2.5"/><circle cx="12" cy="16" r="1.6" fill="#fff" stroke="none"/>';

SG.views.icon = function (n) {
  return (
    '<svg class="i" viewBox="0 0 24 24" aria-hidden="true">' + IC[n] + "</svg>"
  );
};
